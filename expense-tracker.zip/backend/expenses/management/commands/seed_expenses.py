from datetime import date, timedelta
from decimal import Decimal
from django.core.management.base import BaseCommand
from expenses.models import Expense

class Command(BaseCommand):
    help = 'Seeds the database with realistic sample expense records'

    def handle(self, *args, **options):
        if Expense.objects.exists():
            self.stdout.write(self.style.WARNING(f"Database already contains {Expense.objects.count()} expenses. Skipping seed."))
            return

        today = date.today()
        samples = [
            {
                "title": "Whole Foods Grocery Restock",
                "amount": Decimal("142.65"),
                "category": "Shopping & Groceries",
                "date": today - timedelta(days=1),
                "description": "Weekly organic produce, eggs, artisan bread, and pantry staples.",
            },
            {
                "title": "Apartment Monthly Rent",
                "amount": Decimal("1350.00"),
                "category": "Housing & Rent",
                "date": today - timedelta(days=15),
                "description": "Monthly rent payment for 2-bedroom downtown apartment.",
            },
            {
                "title": "Electric & Gas Utility Bill",
                "amount": Decimal("84.20"),
                "category": "Utilities & Bills",
                "date": today - timedelta(days=6),
                "description": "Monthly electricity and natural gas bill.",
            },
            {
                "title": "Downtown Subway Monthly Pass",
                "amount": Decimal("90.00"),
                "category": "Transportation",
                "date": today - timedelta(days=14),
                "description": "Public transit unlimited monthly commuter card.",
            },
            {
                "title": "Team Dinner at Trattoria",
                "amount": Decimal("78.50"),
                "category": "Food & Dining",
                "date": today - timedelta(days=3),
                "description": "Italian dinner with colleagues after project release.",
            },
            {
                "title": "Dental Checkup & Cleaning",
                "amount": Decimal("120.00"),
                "category": "Healthcare & Medical",
                "date": today - timedelta(days=10),
                "description": "Semi-annual routine dental appointment and fluoride.",
            },
            {
                "title": "Streaming Subscriptions",
                "amount": Decimal("29.98"),
                "category": "Entertainment & Leisure",
                "date": today - timedelta(days=8),
                "description": "Monthly Netflix UHD and Spotify Premium bundle.",
            },
            {
                "title": "Technical Books on Cloud Architecture",
                "amount": Decimal("54.90"),
                "category": "Education & Learning",
                "date": today - timedelta(days=4),
                "description": "Designing Data-Intensive Applications paperback.",
            },
            {
                "title": "Weekend Train Ticket to Coast",
                "amount": Decimal("46.00"),
                "category": "Travel",
                "date": today - timedelta(days=2),
                "description": "Roundtrip scenic train ticket for coastal hike.",
            },
            {
                "title": "Ergonomic Desk Mat & Cleaner",
                "amount": Decimal("32.50"),
                "category": "Other",
                "date": today - timedelta(days=12),
                "description": "Felt desk pad and screen cleaning kit for home office.",
            },
        ]

        created_count = 0
        for item in samples:
            Expense.objects.create(**item)
            created_count += 1

        self.stdout.write(self.style.SUCCESS(f"Successfully seeded {created_count} sample expenses!"))
