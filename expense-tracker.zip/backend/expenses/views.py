from django.db.models import Q
from rest_framework import viewsets
from .models import Expense
from .serializers import ExpenseSerializer

class ExpenseViewSet(viewsets.ModelViewSet):
    """
    API endpoint that provides full CRUD operations (GET, POST, PUT, PATCH, DELETE)
    for Expense records, along with filtering by category and search.
    """
    queryset = Expense.objects.all()
    serializer_class = ExpenseSerializer

    def get_queryset(self):
        queryset = Expense.objects.all()
        category = self.request.query_params.get('category', None)
        search = self.request.query_params.get('search', None)
        ordering = self.request.query_params.get('ordering', None)

        if category and category.lower() != 'all':
            queryset = queryset.filter(category__iexact=category)

        if search:
            queryset = queryset.filter(
                Q(title__icontains=search) |
                Q(description__icontains=search) |
                Q(category__icontains=search)
            )

        if ordering:
            # Handle ordering fields safely
            allowed_orderings = ['date', '-date', 'amount', '-amount', 'title', '-title', 'category', '-category', 'created_at', '-created_at']
            if ordering in allowed_orderings:
                queryset = queryset.order_by(ordering)

        return queryset
