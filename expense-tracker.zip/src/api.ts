import axios from 'axios';
import { Expense, ExpenseFormData } from './types';

// Axios instance configured for Django REST Framework endpoints
const apiClient = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

export const expenseApi = {
  // GET all expenses
  getAll: async (params?: { category?: string; search?: string; ordering?: string }): Promise<Expense[]> => {
    const response = await apiClient.get<Expense[] | { results: Expense[] }>('/expenses/', { params });
    // DRF may return an array or paginated object with `results`
    if (Array.isArray(response.data)) {
      return response.data;
    }
    if (response.data && Array.isArray((response.data as any).results)) {
      return (response.data as any).results;
    }
    return [];
  },

  // GET single expense
  getById: async (id: number): Promise<Expense> => {
    const response = await apiClient.get<Expense>(`/expenses/${id}/`);
    return response.data;
  },

  // POST create new expense
  create: async (data: ExpenseFormData): Promise<Expense> => {
    const payload = {
      ...data,
      amount: typeof data.amount === 'string' ? parseFloat(data.amount) : data.amount,
    };
    const response = await apiClient.post<Expense>('/expenses/', payload);
    return response.data;
  },

  // PUT full update
  update: async (id: number, data: ExpenseFormData): Promise<Expense> => {
    const payload = {
      ...data,
      amount: typeof data.amount === 'string' ? parseFloat(data.amount) : data.amount,
    };
    const response = await apiClient.put<Expense>(`/expenses/${id}/`, payload);
    return response.data;
  },

  // PATCH partial update
  patch: async (id: number, data: Partial<ExpenseFormData>): Promise<Expense> => {
    const payload: any = { ...data };
    if (data.amount !== undefined) {
      payload.amount = typeof data.amount === 'string' ? parseFloat(data.amount) : data.amount;
    }
    const response = await apiClient.patch<Expense>(`/expenses/${id}/`, payload);
    return response.data;
  },

  // DELETE expense
  delete: async (id: number): Promise<void> => {
    await apiClient.delete(`/expenses/${id}/`);
  },
};

export default apiClient;
