export interface Expense {
  id: number;
  title: string;
  amount: string | number;
  category: string;
  date: string;
  description?: string;
  created_at?: string;
  updated_at?: string;
}

export type ExpenseFormData = {
  title: string;
  amount: string | number;
  category: string;
  date: string;
  description?: string;
};

export const EXPENSE_CATEGORIES = [
  'Food & Dining',
  'Housing & Rent',
  'Transportation',
  'Utilities & Bills',
  'Healthcare & Medical',
  'Entertainment & Leisure',
  'Shopping & Groceries',
  'Education & Learning',
  'Personal Care',
  'Travel',
  'Other',
] as const;

export type ExpenseCategory = (typeof EXPENSE_CATEGORIES)[number];
